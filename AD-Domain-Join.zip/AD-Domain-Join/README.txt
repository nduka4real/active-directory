ACTIVE DIRECTORY DOMAIN JOIN TOOL
=================================

Files
-----
Join-ADDomain.ps1
    Main PowerShell GUI application.

Run-Join-ADDomain.bat
    Recommended launcher. It automatically requests Administrator privileges.

Logs\
    Log files are created here after the tool runs.

REQUIREMENTS
------------
- Windows 10/11 or Windows Server with PowerShell 5.1+
- Administrator privileges
- Network connectivity to the Domain Controller
- The Domain Controller must provide Active Directory DNS
- The computer must be able to resolve the AD domain through the AD DNS server

HOW TO USE
----------
1. Copy the entire AD-Domain-Join folder to the Windows computer you want to join.
2. Make sure the computer can reach your Domain Controller.
3. Right-click Run-Join-ADDomain.bat and choose Run as administrator.
   The BAT file will also request elevation automatically.
4. Enter:
       Domain DNS Name:
           Example: nduks.lab

       AD DNS / Domain Controller IPv4 Address:
           Example: 192.168.1.10

       Computer Name:
           Example: CLIENT01

       Target OU:
           Optional. Example:
           OU=Computers,DC=nduks,DC=lab

5. Click Configure DNS.
6. Click Test DNS.
7. Click JOIN DOMAIN.
8. Enter an AD account allowed to join computers to the domain.
9. Restart when prompted.

IMPORTANT DNS NOTE
------------------
For Active Directory, the client should use the Domain Controller's DNS service
as its primary DNS server. Do not use public DNS such as 8.8.8.8 as the primary
DNS while trying to join the AD domain.

The script:
- Detects an active physical network adapter.
- Sets the AD DNS server as primary DNS.
- Preserves existing DNS servers as secondary entries when possible.
- Flushes the DNS cache.
- Tests the AD domain and LDAP SRV DNS records.
- Joins the computer using Add-Computer.
- Supports an optional OU path.
- Creates a timestamped log file.

EXAMPLE FOR YOUR LAB
--------------------
Domain DNS:
    nduks.lab

AD DNS / Domain Controller IP:
    192.168.1.10

Computer Name:
    CLIENT01

Target OU:
    OU=Computers,DC=nduks,DC=lab

TROUBLESHOOTING
---------------
If DNS test fails:
- Verify the Domain Controller IP.
- Verify the client and Domain Controller can ping each other.
- Verify the Domain Controller's DNS service is running.
- Verify the client is on the correct network/VLAN.
- Check that the AD DNS zone exists.
- Check that _ldap._tcp.dc._msdcs.<domain> resolves.

If the domain join fails:
- Check the generated file in Logs\.
- Verify the domain credentials.
- Verify the computer name is unique.
- Verify time/date synchronization between the client and Domain Controller.
- Verify firewall/network connectivity.
