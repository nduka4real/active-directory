@echo off
TITLE Active Directory Management Tool
echo Launching AD Management Tool...
echo Logging will be written to AD_Management_Log.txt
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0AD_Management.ps1"
pause