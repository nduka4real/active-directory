@echo off
setlocal
title Active Directory Domain Join

:: Move to the directory containing this BAT file
cd /d "%~dp0"

:: Check for Administrator privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting Administrator privileges...
    powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Join-ADDomain.ps1"

if errorlevel 1 (
    echo.
    echo The PowerShell script returned an error.
    pause
)

endlocal
