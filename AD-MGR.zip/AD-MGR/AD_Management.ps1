﻿#requires -version 5.1
# Active Directory User & Group Management GUI
# Developed by AKPATI NDUKA SUNDAY | github.com/nduka4real
# LDAP/ADSI based - ADWS and the ActiveDirectory module are NOT required.

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$ErrorActionPreference = 'Stop'

# ---------- Logging ----------
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$LogFile = Join-Path $ScriptDir "AD_Management_Log.txt"

function Write-Log {
    param([string]$Message)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $entry = "[$timestamp] $Message"
    Add-Content -Path $LogFile -Value $entry -Encoding UTF8
}

# ---------- Helper Functions ----------
function Show-Info([string]$Text,[string]$Title='AD Management Suite') {
    [void][System.Windows.Forms.MessageBox]::Show($Text,$Title,'OK','Information')
}
function Show-Err([string]$Text,[string]$Title='AD Management Suite') {
    [void][System.Windows.Forms.MessageBox]::Show($Text,$Title,'OK','Error')
}
function Confirm([string]$Text,[string]$Title='Confirm') {
    return ([System.Windows.Forms.MessageBox]::Show($Text,$Title,'YesNo','Warning') -eq [System.Windows.Forms.DialogResult]::Yes)
}

function Get-DomainInfo {
    $root = New-Object System.DirectoryServices.DirectoryEntry('LDAP://RootDSE')
    $root.RefreshCache()
    $dn = [string]$root.Properties['defaultNamingContext'][0]
    if ([string]::IsNullOrWhiteSpace($dn)) { throw 'Unable to determine the Active Directory naming context. Make sure this computer can contact the domain controller.' }
    $dns = [string]$env:USERDNSDOMAIN
    if ([string]::IsNullOrWhiteSpace($dns)) {
        $dns = (($dn -split ',') | Where-Object { $_ -match '^DC=' } | ForEach-Object { $_.Substring(3) }) -join '.'
    }
    [pscustomobject]@{
        DN = $dn
        DNS = $dns
        UsersContainer = "CN=Users,$dn"
        ComputersContainer = "CN=Computers,$dn"
    }
}

try { $Domain = Get-DomainInfo }
catch { Show-Err $_.Exception.Message 'Active Directory Connection Error'; exit 1 }

function New-LdapEntry([string]$DN) {
    $e = New-Object System.DirectoryServices.DirectoryEntry("LDAP://$DN")
    $e.RefreshCache()
    return $e
}

# ---------- Safe Escape Functions ----------
function Escape-LdapFilter([string]$Value) {
    if ($null -eq $Value) { return '' }
    $Value -replace '\\', '\5c' -replace '\*', '\2a' -replace '\(', '\28' -replace '\)', '\29' -replace "`0", '\00'
}

function Escape-LdapRdn([string]$Value) {
    if ($null -eq $Value) { return '' }
    $s = $Value -replace '\\', '\\' -replace ',', '\,' -replace '\+', '\+' -replace '"', '\"' -replace '<', '\<' -replace '>', '\>' -replace ';', '\;' -replace '=', '\='
    if ($s.StartsWith('#')) { $s = '\' + $s }
    if ($s.StartsWith(' ')) { $s = '\ ' }
    if ($s.EndsWith(' ')) { $s = $s.Substring(0,$s.Length-1) + '\ ' }
    return $s
}

# ---------- LDAP Search & Object Functions ----------
function Search-Ldap([string]$Filter,[string]$BaseDN=$Domain.DN,[int]$Size=5000) {
    $base = New-LdapEntry $BaseDN
    $searcher = New-Object System.DirectoryServices.DirectorySearcher($base)
    $searcher.Filter = $Filter
    $searcher.PageSize = 1000
    $searcher.SizeLimit = $Size
    $searcher.SearchScope = [System.DirectoryServices.SearchScope]::Subtree
    foreach ($p in @('distinguishedName','sAMAccountName','userPrincipalName','givenName','sn','displayName','mail','description','userAccountControl','objectClass','cn','ou','groupType','member')) {
        [void]$searcher.PropertiesToLoad.Add($p)
    }
    return $searcher.FindAll()
}

function Get-User([string]$Identity) {
    if ([string]::IsNullOrWhiteSpace($Identity)) { return $null }
    $v = $Identity.Trim()
    if ($v -match '(?i)^(CN|OU|DC)=') {
        try {
            $e = New-LdapEntry $v
            if (@($e.Properties['objectClass']) -contains 'user') { return $e }
        } catch {}
    }
    $safe = Escape-LdapFilter $v
    $rs = Search-Ldap "(&(objectCategory=person)(objectClass=user)(|(sAMAccountName=$safe)(userPrincipalName=$safe)(distinguishedName=$safe)))" $Domain.DN 10
    if ($rs.Count -gt 0) { return (New-LdapEntry ([string]$rs[0].Properties['distinguishedName'][0])) }
    return $null
}

function Get-Group([string]$Identity) {
    if ([string]::IsNullOrWhiteSpace($Identity)) { return $null }
    $v = $Identity.Trim()
    if ($v -match '(?i)^(CN|OU|DC)=') {
        try {
            $e = New-LdapEntry $v
            if (@($e.Properties['objectClass']) -contains 'group') { return $e }
        } catch {}
    }
    $safe = Escape-LdapFilter $v
    $rs = Search-Ldap "(&(objectCategory=group)(|(sAMAccountName=$safe)(cn=$safe)(distinguishedName=$safe)))" $Domain.DN 10
    if ($rs.Count -gt 0) { return (New-LdapEntry ([string]$rs[0].Properties['distinguishedName'][0])) }
    return $null
}

function Get-Users {
    $rs = Search-Ldap '(&(objectCategory=person)(objectClass=user))' $Domain.DN 10000
    $result = @()
    foreach ($r in $rs) {
        try {
            $dn = [string]$r.Properties['distinguishedName'][0]
            $uac = 0
            if ($r.Properties['userAccountControl'].Count -gt 0) { $uac = [int]$r.Properties['userAccountControl'][0] }
            $result += [pscustomobject]@{
                Username = [string]$r.Properties['sAMAccountName'][0]
                FirstName = [string]$r.Properties['givenName'][0]
                LastName = [string]$r.Properties['sn'][0]
                DisplayName = [string]$r.Properties['displayName'][0]
                Email = [string]$r.Properties['mail'][0]
                Description = [string]$r.Properties['description'][0]
                Enabled = (($uac -band 2) -eq 0)
                DN = $dn
            }
        } catch { Write-Log "Error reading user: $_" }
    }
    return $result
}

function Get-Groups {
    $rs = Search-Ldap '(objectCategory=group)' $Domain.DN 10000
    $result = @()
    foreach ($r in $rs) {
        try {
            $result += [pscustomobject]@{
                Name = [string]$r.Properties['cn'][0]
                Sam = [string]$r.Properties['sAMAccountName'][0]
                Description = [string]$r.Properties['description'][0]
                DN = [string]$r.Properties['distinguishedName'][0]
            }
        } catch { Write-Log "Error reading group: $_" }
    }
    return $result
}

function Get-OUs {
    $rs = Search-Ldap '(objectCategory=organizationalUnit)' $Domain.DN 10000
    $result = @()
    foreach ($r in $rs) {
        try { $result += [pscustomobject]@{ Name=[string]$r.Properties['ou'][0]; DN=[string]$r.Properties['distinguishedName'][0] } } catch {}
    }
    return $result
}

function Set-UserPassword([string]$UserDN,[string]$Password) {
    if ([string]::IsNullOrWhiteSpace($Password)) { throw 'Password cannot be empty.' }
    if ($Password.Length -lt 8) { throw 'Password must be at least 8 characters.' }
    $u = New-LdapEntry $UserDN
    try {
        $u.Invoke('SetPassword',$Password)
        $u.CommitChanges()
        Write-Log "Password reset for $UserDN"
    } catch {
        Write-Log "Password reset FAILED for $UserDN`: $_"
        throw "Failed to set password. Ensure it meets domain complexity requirements (length, uppercase, lowercase, digits, special) and the account is not disabled or locked."
    }
}

function Set-UserEnabled([string]$UserDN,[bool]$Enabled) {
    if ([string]::IsNullOrWhiteSpace($UserDN)) { throw 'UserDN cannot be empty.' }
    $u = New-LdapEntry $UserDN
    $uac = [int]$u.Properties['userAccountControl'][0]
    $newUac = $uac
    if ($Enabled) {
        $newUac = $uac -band (-bnot 2)
    } else {
        $newUac = $uac -bor 2
    }
    if ($newUac -ne $uac) {
        $u.Properties['userAccountControl'].Value = $newUac
        $u.CommitChanges()
        Write-Log "Account enabled: $Enabled for $UserDN"
    } else {
        Write-Log "Account state unchanged for $UserDN (already $Enabled)"
    }
}

function New-LdapUser([hashtable]$Data) {
    if (Get-User $Data.Username) { throw "User '$($Data.Username)' already exists." }
    if ([string]::IsNullOrWhiteSpace($Data.Password)) { throw 'Password is required.' }
    $parent = New-LdapEntry $Data.Path
    $cn = [string]$Data.DisplayName
    if ([string]::IsNullOrWhiteSpace($cn)) { $cn = (($Data.FirstName + ' ' + $Data.LastName).Trim()) }
    if ([string]::IsNullOrWhiteSpace($cn)) { $cn = [string]$Data.Username }
    $cnEsc = Escape-LdapRdn $cn
    $u = $parent.Children.Add("CN=$cnEsc",'user')
    try {
        $u.Properties['sAMAccountName'].Value = [string]$Data.Username
        $u.Properties['userPrincipalName'].Value = "{0}@{1}" -f $Data.Username,$Domain.DNS
        if (-not [string]::IsNullOrWhiteSpace($Data.FirstName)) { $u.Properties['givenName'].Value = $Data.FirstName }
        if (-not [string]::IsNullOrWhiteSpace($Data.LastName)) { $u.Properties['sn'].Value = $Data.LastName }
        $u.Properties['displayName'].Value = $cn
        if (-not [string]::IsNullOrWhiteSpace($Data.Email)) { $u.Properties['mail'].Value = $Data.Email }
        if (-not [string]::IsNullOrWhiteSpace($Data.Description)) { $u.Properties['description'].Value = $Data.Description }
        $u.Properties['userAccountControl'].Value = 514
        $u.CommitChanges()
        $dn = [string]$u.Properties['distinguishedName'][0]
        Set-UserPassword $dn $Data.Password
        Set-UserEnabled $dn ([bool]$Data.Enabled)
        try { Add-UserToGroup $dn 'Domain Users' } catch { Write-Log "Failed to add to Domain Users: $_" }
        Write-Log "User created: $($Data.Username) ($dn)"
        return (Get-User $Data.Username)
    } catch {
        Write-Log "User creation failed: $_"
        throw
    }
}

function Update-LdapUser([string]$UserDN,[hashtable]$Data) {
    if ([string]::IsNullOrWhiteSpace($UserDN)) { throw 'UserDN cannot be empty.' }
    $u = New-LdapEntry $UserDN
    foreach ($pair in @(@('givenName',$Data.FirstName),@('sn',$Data.LastName),@('displayName',$Data.DisplayName),@('mail',$Data.Email),@('description',$Data.Description))) {
        $attr = $pair[0]; $val = [string]$pair[1]
        if ([string]::IsNullOrWhiteSpace($val)) { $u.Properties[$attr].Clear() } else { $u.Properties[$attr].Value = $val }
    }
    $u.CommitChanges()
    if (-not [string]::IsNullOrWhiteSpace($Data.Password)) { Set-UserPassword $UserDN $Data.Password }
    Set-UserEnabled $UserDN ([bool]$Data.Enabled)
    Write-Log "User updated: $UserDN"
}

function New-LdapGroup([string]$Name,[string]$Description,[string]$Type,[string]$Path) {
    if (Get-Group $Name) { throw "Group '$Name' already exists." }
    if ([string]::IsNullOrWhiteSpace($Name)) { throw 'Group name is required.' }
    $parent = New-LdapEntry $Path
    $g = $parent.Children.Add("CN=$(Escape-LdapRdn $Name)",'group')
    switch ($Type) {
        'Global' { $gt = -2147483646 }
        'Universal' { $gt = -2147483640 }
        'DomainLocal' { $gt = -2147483644 }
        default { $gt = -2147483646 }
    }
    $g.Properties['sAMAccountName'].Value = $Name
    if (-not [string]::IsNullOrWhiteSpace($Description)) { $g.Properties['description'].Value = $Description }
    $g.Properties['groupType'].Value = $gt
    $g.CommitChanges()
    Write-Log "Group created: $Name ($Path)"
}

function Add-UserToGroup([string]$UserDN,[string]$GroupName) {
    if ([string]::IsNullOrWhiteSpace($UserDN)) { throw 'UserDN cannot be empty.' }
    if ([string]::IsNullOrWhiteSpace($GroupName)) { throw 'GroupName cannot be empty.' }
    $g = Get-Group $GroupName
    if (-not $g) { throw "Group '$GroupName' not found." }
    $g.RefreshCache()
    $members = @($g.Properties['member'])
    if ($members -contains $UserDN) { return }
    $g.Properties['member'].Add($UserDN)
    $g.CommitChanges()
    Write-Log "Added $UserDN to group $GroupName"
}

function Remove-UserFromGroup([string]$UserDN,[string]$GroupName) {
    if ([string]::IsNullOrWhiteSpace($UserDN)) { throw 'UserDN cannot be empty.' }
    if ([string]::IsNullOrWhiteSpace($GroupName)) { throw 'GroupName cannot be empty.' }
    $g = Get-Group $GroupName
    if (-not $g) { throw "Group '$GroupName' not found." }
    try {
        $g.Properties['member'].Remove($UserDN)
        $g.CommitChanges()
        Write-Log "Removed $UserDN from group $GroupName"
    } catch { throw }
}

function Get-GroupMembers([string]$GroupDN) {
    if ([string]::IsNullOrWhiteSpace($GroupDN)) { throw 'GroupDN cannot be empty.' }
    $g = New-LdapEntry $GroupDN
    $result = @()
    foreach ($dn in @($g.Properties['member'])) {
        try {
            $e = New-LdapEntry ([string]$dn)
            $result += [pscustomobject]@{ Username=[string]$e.Properties['sAMAccountName'][0]; DisplayName=[string]$e.Properties['displayName'][0]; DN=[string]$dn }
        } catch { Write-Log "Could not read member $dn`: $_" }
    }
    return $result
}

function New-LdapOU([string]$Name,[string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Name)) { throw 'OU name is required.' }
    $safe = Escape-LdapFilter $Name
    $rs = Search-Ldap "(&(objectCategory=organizationalUnit)(ou=$safe))" $Path 10
    if ($rs.Count -gt 0) { throw "OU '$Name' already exists at this location." }
    $p = New-LdapEntry $Path
    $ou = $p.Children.Add("OU=$(Escape-LdapRdn $Name)",'organizationalUnit')
    $ou.CommitChanges()
    Write-Log "OU created: $Name under $Path"
}

function Delete-LdapObject([string]$DN) {
    if ([string]::IsNullOrWhiteSpace($DN)) { throw 'DN cannot be empty.' }
    $e = New-LdapEntry $DN
    $p = $e.Parent
    $p.Delete($e.SchemaClassName,$e.Name)
    $p.CommitChanges()
    Write-Log "Deleted object: $DN"
}

# ---------------- GUI ----------------
$form = New-Object System.Windows.Forms.Form
$form.Text = "Active Directory Management Suite - $($Domain.DNS)"
$form.Size = New-Object System.Drawing.Size(1200,780)
$form.MinimumSize = New-Object System.Drawing.Size(1000,650)
$form.StartPosition = 'CenterScreen'
$form.Font = New-Object System.Drawing.Font('Segoe UI',9)

$header = New-Object System.Windows.Forms.Panel
$header.Dock='Top';$header.Height=72;$header.BackColor=[System.Drawing.Color]::FromArgb(35,55,75)
$title = New-Object System.Windows.Forms.Label
$title.Text='ACTIVE DIRECTORY MANAGEMENT SUITE';$title.ForeColor='White';$title.Font=New-Object System.Drawing.Font('Segoe UI',16,[System.Drawing.FontStyle]::Bold);$title.Location=New-Object System.Drawing.Point(20,9);$title.AutoSize=$true
$sub = New-Object System.Windows.Forms.Label
$sub.Text="Domain: $($Domain.DNS)  |  LDAP/ADSI  |  Developed by AKPATI NDUKA SUNDAY (github.com/nduka4real)";$sub.ForeColor='White';$sub.Location=New-Object System.Drawing.Point(22,43);$sub.AutoSize=$true
$header.Controls.AddRange(@($title,$sub));$form.Controls.Add($header)

$nav = New-Object System.Windows.Forms.Panel
$nav.Dock='Top';$nav.Height=48;$nav.BackColor=[System.Drawing.Color]::FromArgb(225,232,238)
$form.Controls.Add($nav)

$tabs = New-Object System.Windows.Forms.TabControl
$tabs.Dock='Fill';$tabs.Appearance='Normal';$form.Controls.Add($tabs)
$form.Controls.SetChildIndex($tabs,2)
$form.Controls.SetChildIndex($nav,1)
$form.Controls.SetChildIndex($header,0)

function New-NavButton([string]$Text,[int]$X) {
    $b=New-Object System.Windows.Forms.Button
    $b.Text=$Text;$b.Location=New-Object System.Drawing.Point($X,8);$b.Size=New-Object System.Drawing.Size(125,32)
    $b.Font=New-Object System.Drawing.Font('Segoe UI',9,[System.Drawing.FontStyle]::Bold)
    [void]$nav.Controls.Add($b); return $b
}
$navHome=New-NavButton 'MAIN SCREEN' 10
$navUsers=New-NavButton 'USERS' 140
$navGroups=New-NavButton 'GROUPS' 270
$navOU=New-NavButton 'OUs' 400
$navBulk=New-NavButton 'BULK IMPORT' 530
$navTools=New-NavButton 'AD TOOLS' 660
$navDomain=New-Object System.Windows.Forms.Label
$navDomain.Text="Connected: $($Domain.DNS)";$navDomain.Location=New-Object System.Drawing.Point(800,15);$navDomain.AutoSize=$true
[void]$nav.Controls.Add($navDomain)

# Home
$tabHome=New-Object System.Windows.Forms.TabPage;$tabHome.Text='Home';[void]$tabs.TabPages.Add($tabHome)
$homeTitle=New-Object System.Windows.Forms.Label;$homeTitle.Text='Active Directory User & Group Management';$homeTitle.Font=New-Object System.Drawing.Font('Segoe UI',18,[System.Drawing.FontStyle]::Bold);$homeTitle.Location=New-Object System.Drawing.Point(35,25);$homeTitle.AutoSize=$true
$homeInfo=New-Object System.Windows.Forms.Label;$homeInfo.Text="Domain: $($Domain.DNS)`r`n`r`nSelect an operation:`r`nManage users, groups, group membership, OUs and bulk user imports.`r`nAll operations are performed directly against Active Directory through LDAP/ADSI.";$homeInfo.Location=New-Object System.Drawing.Point(37,70);$homeInfo.AutoSize=$true
function New-HomeButton([string]$Text,[int]$X,[int]$Y) {
    $b=New-Object System.Windows.Forms.Button;$b.Text=$Text;$b.Location=New-Object System.Drawing.Point($X,$Y);$b.Size=New-Object System.Drawing.Size(205,55);$b.Font=New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold);return $b
}
$homeAddUser=New-HomeButton 'ADD USER' 35 180
$homeManageUsers=New-HomeButton 'MANAGE USERS' 255 180
$homeCreateGroup=New-HomeButton 'CREATE GROUP' 475 180
$homeManageGroups=New-HomeButton 'MANAGE GROUPS' 695 180
$homeOU=New-HomeButton 'MANAGE OUs' 35 250
$homeBulk=New-HomeButton 'BULK CSV IMPORT' 255 250
$homeMembers=New-HomeButton 'GROUP MEMBERS' 475 250
$homeTools=New-HomeButton 'AD TOOLS / DIAGNOSTICS' 695 250
$homeFooter=New-Object System.Windows.Forms.Label;$homeFooter.Text="Developed by AKPATI NDUKA SUNDAY | github.com/nduka4real";$homeFooter.Location=New-Object System.Drawing.Point(37,335);$homeFooter.AutoSize=$true;$homeFooter.Font=New-Object System.Drawing.Font('Segoe UI',9,[System.Drawing.FontStyle]::Italic)
$tabHome.Controls.AddRange(@($homeTitle,$homeInfo,$homeAddUser,$homeManageUsers,$homeCreateGroup,$homeManageGroups,$homeOU,$homeBulk,$homeMembers,$homeTools,$homeFooter))

function Add-BackHomeButton([System.Windows.Forms.TabPage]$Tab) {
    $b=New-Object System.Windows.Forms.Button;$b.Text='← MAIN SCREEN';$b.Location=New-Object System.Drawing.Point(15,8);$b.Size=New-Object System.Drawing.Size(130,32);$b.Font=New-Object System.Drawing.Font('Segoe UI',9,[System.Drawing.FontStyle]::Bold);$b.Add_Click({$tabs.SelectedTab=$tabHome});$Tab.Controls.Add($b);return $b
}

# Users
$tabUsers=New-Object System.Windows.Forms.TabPage;$tabUsers.Text='Users';[void]$tabs.TabPages.Add($tabUsers);[void](Add-BackHomeButton $tabUsers)
$btnRefresh=New-Object System.Windows.Forms.Button;$btnRefresh.Text='Refresh';$btnRefresh.Location=New-Object System.Drawing.Point(150,8);$btnRefresh.Size=New-Object System.Drawing.Size(85,32)
$btnAdd=New-Object System.Windows.Forms.Button;$btnAdd.Text='Add User';$btnAdd.Location=New-Object System.Drawing.Point(245,8);$btnAdd.Size=New-Object System.Drawing.Size(95,32)
$btnEdit=New-Object System.Windows.Forms.Button;$btnEdit.Text='Edit User';$btnEdit.Location=New-Object System.Drawing.Point(350,8);$btnEdit.Size=New-Object System.Drawing.Size(95,32)
$btnDelete=New-Object System.Windows.Forms.Button;$btnDelete.Text='Delete User';$btnDelete.Location=New-Object System.Drawing.Point(455,8);$btnDelete.Size=New-Object System.Drawing.Size(100,32)
$btnReset=New-Object System.Windows.Forms.Button;$btnReset.Text='Reset Password';$btnReset.Location=New-Object System.Drawing.Point(565,8);$btnReset.Size=New-Object System.Drawing.Size(120,32)
$btnToggle=New-Object System.Windows.Forms.Button;$btnToggle.Text='Enable/Disable';$btnToggle.Location=New-Object System.Drawing.Point(695,8);$btnToggle.Size=New-Object System.Drawing.Size(115,32)
$btnAddGroup=New-Object System.Windows.Forms.Button;$btnAddGroup.Text='Add to Group';$btnAddGroup.Location=New-Object System.Drawing.Point(820,8);$btnAddGroup.Size=New-Object System.Drawing.Size(105,32)
$btnDetails=New-Object System.Windows.Forms.Button;$btnDetails.Text='View Details';$btnDetails.Location=New-Object System.Drawing.Point(935,8);$btnDetails.Size=New-Object System.Drawing.Size(105,32)
$grid=New-Object System.Windows.Forms.DataGridView;$grid.Location=New-Object System.Drawing.Point(15,52);$grid.Size=New-Object System.Drawing.Size(1140,625);$grid.Anchor='Top,Bottom,Left,Right';$grid.ReadOnly=$true;$grid.SelectionMode='FullRowSelect';$grid.MultiSelect=$false;$grid.AllowUserToAddRows=$false;$grid.AutoGenerateColumns=$false;$grid.RowHeadersVisible=$false
foreach($col in @(@('Username',110),@('FirstName',110),@('LastName',110),@('DisplayName',180),@('Email',210),@('Enabled',70),@('Description',180))) { $c=New-Object System.Windows.Forms.DataGridViewTextBoxColumn;$c.Name=$col[0];$c.HeaderText=$col[0];$c.Width=$col[1];[void]$grid.Columns.Add($c) }
$userHint=New-Object System.Windows.Forms.Label;$userHint.Text='Select a user in the list to enable Edit, Reset Password, Add to Group, Enable/Disable, Delete and View Details.';$userHint.Location=New-Object System.Drawing.Point(15,685);$userHint.AutoSize=$true;$tabUsers.Controls.AddRange(@($btnRefresh,$btnAdd,$btnEdit,$btnDelete,$btnReset,$btnToggle,$btnAddGroup,$btnDetails,$grid,$userHint))

# Groups
$tabGroups=New-Object System.Windows.Forms.TabPage;$tabGroups.Text='Groups';[void]$tabs.TabPages.Add($tabGroups);[void](Add-BackHomeButton $tabGroups)
$gbRefresh=New-Object System.Windows.Forms.Button;$gbRefresh.Text='Refresh';$gbRefresh.Location=New-Object System.Drawing.Point(150,8);$gbRefresh.Size=New-Object System.Drawing.Size(85,32)
$gbAdd=New-Object System.Windows.Forms.Button;$gbAdd.Text='Create Group';$gbAdd.Location=New-Object System.Drawing.Point(245,8);$gbAdd.Size=New-Object System.Drawing.Size(105,32)
$gbMembers=New-Object System.Windows.Forms.Button;$gbMembers.Text='Manage Members';$gbMembers.Location=New-Object System.Drawing.Point(360,8);$gbMembers.Size=New-Object System.Drawing.Size(125,32)
$gbDelete=New-Object System.Windows.Forms.Button;$gbDelete.Text='Delete Group';$gbDelete.Location=New-Object System.Drawing.Point(495,8);$gbDelete.Size=New-Object System.Drawing.Size(105,32)
$gbEdit=New-Object System.Windows.Forms.Button;$gbEdit.Text='Edit Group';$gbEdit.Location=New-Object System.Drawing.Point(610,8);$gbEdit.Size=New-Object System.Drawing.Size(95,32)
$gbDetails=New-Object System.Windows.Forms.Button;$gbDetails.Text='Group Details';$gbDetails.Location=New-Object System.Drawing.Point(715,8);$gbDetails.Size=New-Object System.Drawing.Size(105,32)
$ggrid=New-Object System.Windows.Forms.DataGridView;$ggrid.Location=New-Object System.Drawing.Point(15,52);$ggrid.Size=New-Object System.Drawing.Size(1140,625);$ggrid.Anchor='Top,Bottom,Left,Right';$ggrid.ReadOnly=$true;$ggrid.SelectionMode='FullRowSelect';$ggrid.MultiSelect=$false;$ggrid.AllowUserToAddRows=$false;$ggrid.AutoGenerateColumns=$false;$ggrid.RowHeadersVisible=$false
foreach($col in @(@('Name',240),@('Sam',180),@('Description',300),@('DN',390))) { $c=New-Object System.Windows.Forms.DataGridViewTextBoxColumn;$c.Name=$col[0];$c.HeaderText=$col[0];$c.Width=$col[1];[void]$ggrid.Columns.Add($c) }
$groupHint=New-Object System.Windows.Forms.Label;$groupHint.Text='Select a group to manage members, edit details or delete it.';$groupHint.Location=New-Object System.Drawing.Point(15,685);$groupHint.AutoSize=$true;$tabGroups.Controls.AddRange(@($gbRefresh,$gbAdd,$gbMembers,$gbDelete,$gbEdit,$gbDetails,$ggrid,$groupHint))

# OUs
$tabOU=New-Object System.Windows.Forms.TabPage;$tabOU.Text='Organizational Units';[void]$tabs.TabPages.Add($tabOU);[void](Add-BackHomeButton $tabOU)
$obRefresh=New-Object System.Windows.Forms.Button;$obRefresh.Text='Refresh';$obRefresh.Location=New-Object System.Drawing.Point(150,8);$obRefresh.Size=New-Object System.Drawing.Size(85,32)
$obAdd=New-Object System.Windows.Forms.Button;$obAdd.Text='Create OU';$obAdd.Location=New-Object System.Drawing.Point(245,8);$obAdd.Size=New-Object System.Drawing.Size(95,32)
$obDelete=New-Object System.Windows.Forms.Button;$obDelete.Text='Delete OU';$obDelete.Location=New-Object System.Drawing.Point(350,8);$obDelete.Size=New-Object System.Drawing.Size(95,32)
$ouHint = New-Object System.Windows.Forms.Label
$ouHint.Text = "Select an OU from the list, then click Create OU or Delete OU."
$ouHint.Location = New-Object System.Drawing.Point(460, 12)
$ouHint.AutoSize = $true
$ogrid=New-Object System.Windows.Forms.DataGridView;$ogrid.Location=New-Object System.Drawing.Point(15,52);$ogrid.Size=New-Object System.Drawing.Size(1140,625);$ogrid.Anchor='Top,Bottom,Left,Right';$ogrid.ReadOnly=$true;$ogrid.SelectionMode='FullRowSelect';$ogrid.MultiSelect=$false;$ogrid.AllowUserToAddRows=$false;$ogrid.AutoGenerateColumns=$false;$ogrid.RowHeadersVisible=$false
foreach($col in @(@('Name',220),@('DN',800))) { $c=New-Object System.Windows.Forms.DataGridViewTextBoxColumn;$c.Name=$col[0];$c.HeaderText=$col[0];$c.Width=$col[1];[void]$ogrid.Columns.Add($c) }
$tabOU.Controls.AddRange(@($obRefresh,$obAdd,$obDelete,$ouHint,$ogrid))

# ---------- BULK IMPORT – with "Create Sample CSV" button under Import ----------
$tabBulk = New-Object System.Windows.Forms.TabPage
$tabBulk.Text = 'Bulk Import'
[void]$tabs.TabPages.Add($tabBulk)
[void](Add-BackHomeButton $tabBulk)

# Panel for the entire bulk import area
$bulkPanel = New-Object System.Windows.Forms.Panel
$bulkPanel.Location = New-Object System.Drawing.Point(155, 45)
$bulkPanel.Size = New-Object System.Drawing.Size(970, 180)
$bulkPanel.BorderStyle = 'FixedSingle'

$bulkInfo = New-Object System.Windows.Forms.Label
$bulkInfo.Text = "CSV format: Username,FirstName,LastName,DisplayName,Email,Description,Password,OU`r`nUsername and Password are required. Existing users are skipped. Domain Users membership is automatic."
$bulkInfo.Location = New-Object System.Drawing.Point(10, 10)
$bulkInfo.AutoSize = $true
$bulkPanel.Controls.Add($bulkInfo)

$lblFile = New-Object System.Windows.Forms.Label
$lblFile.Text = "Select CSV file:"
$lblFile.Location = New-Object System.Drawing.Point(10, 60)
$lblFile.Size = New-Object System.Drawing.Size(100, 25)
$bulkPanel.Controls.Add($lblFile)

$csvBox = New-Object System.Windows.Forms.TextBox
$csvBox.Location = New-Object System.Drawing.Point(120, 58)
$csvBox.Size = New-Object System.Drawing.Size(620, 28)
$csvBox.ReadOnly = $true
$csvBox.BackColor = [System.Drawing.Color]::White
$bulkPanel.Controls.Add($csvBox)

$browse = New-Object System.Windows.Forms.Button
$browse.Text = 'Browse...'
$browse.Location = New-Object System.Drawing.Point(750, 56)
$browse.Size = New-Object System.Drawing.Size(100, 30)
$bulkPanel.Controls.Add($browse)

$import = New-Object System.Windows.Forms.Button
$import.Text = 'Import'
$import.Location = New-Object System.Drawing.Point(860, 56)
$import.Size = New-Object System.Drawing.Size(90, 30)
$bulkPanel.Controls.Add($import)

# "Create Sample CSV" button – placed below the Import button
$sample = New-Object System.Windows.Forms.Button
$sample.Text = 'Create Sample CSV'
$sample.Location = New-Object System.Drawing.Point(10, 100)   # below the file selection row
$sample.Size = New-Object System.Drawing.Size(140, 30)
$bulkPanel.Controls.Add($sample)

$tabBulk.Controls.Add($bulkPanel)

# Log output
$bulkLog = New-Object System.Windows.Forms.TextBox
$bulkLog.Multiline = $true
$bulkLog.ScrollBars = 'Both'
$bulkLog.ReadOnly = $true
$bulkLog.Location = New-Object System.Drawing.Point(155, 235)
$bulkLog.Size = New-Object System.Drawing.Size(970, 440)
$bulkLog.Anchor = 'Top,Bottom,Left,Right'
$tabBulk.Controls.Add($bulkLog)

# ---------- TOOLS ----------
$tabTools = New-Object System.Windows.Forms.TabPage
$tabTools.Text = 'Tools'
[void]$tabs.TabPages.Add($tabTools)
[void](Add-BackHomeButton $tabTools)

$toolPanel = New-Object System.Windows.Forms.Panel
$toolPanel.Location = New-Object System.Drawing.Point(155, 8)
$toolPanel.Size = New-Object System.Drawing.Size(970, 130)
$toolPanel.BorderStyle = 'FixedSingle'

$toolLabel = New-Object System.Windows.Forms.Label
$toolLabel.Text = 'AD Tools & Diagnostics'
$toolLabel.Font = New-Object System.Drawing.Font('Segoe UI', 12, [System.Drawing.FontStyle]::Bold)
$toolLabel.Location = New-Object System.Drawing.Point(10, 10)
$toolLabel.AutoSize = $true
$toolPanel.Controls.Add($toolLabel)

$diag = New-Object System.Windows.Forms.Button
$diag.Text = 'Run LDAP Diagnostics'
$diag.Location = New-Object System.Drawing.Point(10, 45)
$diag.Size = New-Object System.Drawing.Size(170, 35)
$toolPanel.Controls.Add($diag)

$openADUC = New-Object System.Windows.Forms.Button
$openADUC.Text = 'Open AD Users & Computers'
$openADUC.Location = New-Object System.Drawing.Point(190, 45)
$openADUC.Size = New-Object System.Drawing.Size(200, 35)
$toolPanel.Controls.Add($openADUC)

$copyDomain = New-Object System.Windows.Forms.Button
$copyDomain.Text = 'Copy Domain Info'
$copyDomain.Location = New-Object System.Drawing.Point(400, 45)
$copyDomain.Size = New-Object System.Drawing.Size(160, 35)
$toolPanel.Controls.Add($copyDomain)

$clearBtn = New-Object System.Windows.Forms.Button
$clearBtn.Text = 'Clear Output'
$clearBtn.Location = New-Object System.Drawing.Point(570, 45)
$clearBtn.Size = New-Object System.Drawing.Size(100, 35)
$toolPanel.Controls.Add($clearBtn)

$toolOut = New-Object System.Windows.Forms.TextBox
$toolOut.Multiline = $true
$toolOut.ReadOnly = $true
$toolOut.ScrollBars = 'Both'
$toolOut.Location = New-Object System.Drawing.Point(155, 145)
$toolOut.Size = New-Object System.Drawing.Size(970, 530)
$toolOut.Anchor = 'Top,Bottom,Left,Right'
$toolOut.Text = "Click 'Run LDAP Diagnostics' to verify connectivity.`r`nYou can also open ADUC or copy domain info."

$tabTools.Controls.Add($toolPanel)
$tabTools.Controls.Add($toolOut)

# ---------- GRID REFRESH FUNCTIONS ----------
function Refresh-Users {
    try {
        $grid.Rows.Clear()
        $items = @(Get-Users | Sort-Object Username)
        foreach($u in $items) {
            $i=$grid.Rows.Add();$r=$grid.Rows[$i]
            $r.Cells['Username'].Value=$u.Username
            $r.Cells['FirstName'].Value=$u.FirstName
            $r.Cells['LastName'].Value=$u.LastName
            $r.Cells['DisplayName'].Value=$u.DisplayName
            $r.Cells['Email'].Value=$u.Email
            $r.Cells['Enabled'].Value=$(if($u.Enabled){'Yes'}else{'No'})
            $r.Cells['Description'].Value=$u.Description
            $r.Tag = $u
        }
        $grid.ClearSelection()
    } catch { Show-Err "Unable to load users.`r`n`r`n$($_.Exception.Message)" }
}

function Refresh-Groups {
    try {
        $ggrid.Rows.Clear()
        $items=@(Get-Groups | Sort-Object Name)
        foreach($g in $items) {
            $i=$ggrid.Rows.Add();$r=$ggrid.Rows[$i]
            $r.Cells['Name'].Value=$g.Name
            $r.Cells['Sam'].Value=$g.Sam
            $r.Cells['Description'].Value=$g.Description
            $r.Cells['DN'].Value=$g.DN
            $r.Tag = $g
        }
        $ggrid.ClearSelection()
    } catch { Show-Err "Unable to load groups.`r`n`r`n$($_.Exception.Message)" }
}

function Refresh-OUs {
    try {
        $ogrid.Rows.Clear()
        $items=@(Get-OUs | Sort-Object DN)
        foreach($o in $items) {
            $i=$ogrid.Rows.Add();$r=$ogrid.Rows[$i]
            $r.Cells['Name'].Value=$o.Name
            $r.Cells['DN'].Value=$o.DN
            $r.Tag = $o
        }
        $ogrid.ClearSelection()
    } catch { Show-Err "Unable to load OUs.`r`n`r`n$($_.Exception.Message)" }
}

function Selected-User {
    if ($grid.SelectedRows.Count -eq 0) { Show-Info 'Select a user first.'; return $null }
    $u = $grid.SelectedRows[0].Tag
    if ($null -eq $u) { Show-Err 'Internal error: user data not found.'; return $null }
    return $u
}

function Selected-Group {
    if ($ggrid.SelectedRows.Count -eq 0) { Show-Info 'Select a group first.'; return $null }
    $g = $ggrid.SelectedRows[0].Tag
    if ($null -eq $g) { Show-Err 'Internal error: group data not found.'; return $null }
    return $g
}

# ---------- DIALOGS ----------
function Show-UserDialog([object]$Existing=$null) {
    $f=New-Object System.Windows.Forms.Form
    $f.Text=$(if($Existing){'Edit User'}else{'Add User'})
    $f.Size=New-Object System.Drawing.Size(560,570)
    $f.StartPosition='CenterParent'
    $f.FormBorderStyle='FixedDialog'
    $f.MaximizeBox=$false
    $fields=@{}
    $labels=@('Username','First Name','Last Name','Display Name','Email','Description','Password')
    $y=20
    foreach($n in $labels) {
        $l=New-Object System.Windows.Forms.Label;$l.Text=$n;$l.Location=New-Object System.Drawing.Point(20,($y+4));$l.Size=New-Object System.Drawing.Size(105,24)
        $t=New-Object System.Windows.Forms.TextBox;$t.Location=New-Object System.Drawing.Point(135,$y);$t.Size=New-Object System.Drawing.Size(380,25)
        if($n -eq 'Password'){$t.UseSystemPasswordChar=$true}
        if($Existing){$map=@{'Username'='Username';'First Name'='FirstName';'Last Name'='LastName';'Display Name'='DisplayName';'Email'='Email';'Description'='Description'};$prop=$map[$n];$t.Text=[string]$Existing.$prop}
        if($n -eq 'Username' -and $Existing){$t.ReadOnly=$true}
        $f.Controls.AddRange(@($l,$t));$fields[$n]=$t;$y+=52
    }
    $ouLab=New-Object System.Windows.Forms.Label;$ouLab.Text='OU / Container';$ouLab.Location=New-Object System.Drawing.Point(20,($y+4));$ouLab.Size=New-Object System.Drawing.Size(105,24)
    $ou=New-Object System.Windows.Forms.ComboBox;$ou.Location=New-Object System.Drawing.Point(135,$y);$ou.Size=New-Object System.Drawing.Size(380,25);$ou.DropDownStyle='DropDownList';[void]$ou.Items.Add("Default: $($Domain.UsersContainer)");foreach($x in @(Get-OUs | Sort-Object DN)){[void]$ou.Items.Add($x.DN)};$ou.SelectedIndex=0;$f.Controls.AddRange(@($ouLab,$ou));$y+=48
    $enabled=New-Object System.Windows.Forms.CheckBox;$enabled.Text='Account enabled';$enabled.Location=New-Object System.Drawing.Point(135,$y);$enabled.Checked=$(if($Existing){$Existing.Enabled}else{$true});$f.Controls.Add($enabled);$y+=42
    $save=New-Object System.Windows.Forms.Button;$save.Text=$(if($Existing){'Save Changes'}else{'Create User'});$save.Location=New-Object System.Drawing.Point(135,$y);$save.Size=New-Object System.Drawing.Size(130,34)
    $cancel=New-Object System.Windows.Forms.Button;$cancel.Text='Cancel';$cancel.Location=New-Object System.Drawing.Point(280,$y);$cancel.Size=New-Object System.Drawing.Size(90,34);$f.Controls.AddRange(@($save,$cancel));$cancel.Add_Click({$f.Close()})
    $save.Add_Click({
        try {
            $username=$fields['Username'].Text.Trim()
            if([string]::IsNullOrWhiteSpace($username)){throw 'Username is required.'}
            if(-not $Existing -and [string]::IsNullOrWhiteSpace($fields['Password'].Text)){throw 'Password is required for a new user.'}
            if(-not $Existing -and $fields['Password'].Text.Length -lt 8){throw 'Password must be at least 8 characters.'}
            $path=$Domain.UsersContainer
            if($ou.SelectedIndex -gt 0){$path=[string]$ou.SelectedItem}
            $data=@{
                Username=$username
                FirstName=$fields['First Name'].Text.Trim()
                LastName=$fields['Last Name'].Text.Trim()
                DisplayName=$fields['Display Name'].Text.Trim()
                Email=$fields['Email'].Text.Trim()
                Description=$fields['Description'].Text.Trim()
                Password=$fields['Password'].Text
                Enabled=$enabled.Checked
                Path=$path
            }
            if($Existing){Update-LdapUser $Existing.DN $data}else{[void](New-LdapUser $data)}
            $f.Close();Refresh-Users;Show-Info $(if($Existing){'User updated successfully.'}else{'User created successfully.'})
        } catch { Show-Err "User operation failed:`r`n`r`n$($_.Exception.Message)" }
    })
    [void]$f.ShowDialog($form)
}

function Show-GroupDialog {
    $f=New-Object System.Windows.Forms.Form;$f.Text='Create Group';$f.Size=New-Object System.Drawing.Size(500,330);$f.StartPosition='CenterParent';$f.FormBorderStyle='FixedDialog';$f.MaximizeBox=$false
    $l1=New-Object System.Windows.Forms.Label;$l1.Text='Group Name';$l1.Location=New-Object System.Drawing.Point(20,25);$t1=New-Object System.Windows.Forms.TextBox;$t1.Location=New-Object System.Drawing.Point(140,22);$t1.Size=New-Object System.Drawing.Size(320,25)
    $l2=New-Object System.Windows.Forms.Label;$l2.Text='Description';$l2.Location=New-Object System.Drawing.Point(20,65);$t2=New-Object System.Windows.Forms.TextBox;$t2.Location=New-Object System.Drawing.Point(140,62);$t2.Size=New-Object System.Drawing.Size(320,50)
    $l3=New-Object System.Windows.Forms.Label;$l3.Text='Scope';$l3.Location=New-Object System.Drawing.Point(20,135);$c=New-Object System.Windows.Forms.ComboBox;$c.Location=New-Object System.Drawing.Point(140,132);$c.Size=New-Object System.Drawing.Size(320,25);$c.DropDownStyle='DropDownList';$c.Items.AddRange(@('Global','Universal','DomainLocal'));$c.SelectedIndex=0
    $l4=New-Object System.Windows.Forms.Label;$l4.Text='Container';$l4.Location=New-Object System.Drawing.Point(20,175);$ou=New-Object System.Windows.Forms.ComboBox;$ou.Location=New-Object System.Drawing.Point(140,172);$ou.Size=New-Object System.Drawing.Size(320,25);$ou.DropDownStyle='DropDownList';[void]$ou.Items.Add("Default: $($Domain.UsersContainer)");foreach($x in @(Get-OUs | Sort-Object DN)){[void]$ou.Items.Add($x.DN)};$ou.SelectedIndex=0
    $b=New-Object System.Windows.Forms.Button;$b.Text='Create Group';$b.Location=New-Object System.Drawing.Point(140,220);$b.Size=New-Object System.Drawing.Size(110,32)
    $cancel=New-Object System.Windows.Forms.Button;$cancel.Text='Cancel';$cancel.Location=New-Object System.Drawing.Point(265,220);$cancel.Size=New-Object System.Drawing.Size(90,32)
    $f.Controls.AddRange(@($l1,$t1,$l2,$t2,$l3,$c,$l4,$ou,$b,$cancel));$cancel.Add_Click({$f.Close()})
    $b.Add_Click({try{if([string]::IsNullOrWhiteSpace($t1.Text)){throw 'Group name is required.'};$path=$Domain.UsersContainer;if($ou.SelectedIndex -gt 0){$path=[string]$ou.SelectedItem};New-LdapGroup $t1.Text.Trim() $t2.Text.Trim() $c.SelectedItem $path;$f.Close();Refresh-Groups;Show-Info 'Group created successfully.'}catch{Show-Err "Group creation failed:`r`n`r`n$($_.Exception.Message)"}})
    [void]$f.ShowDialog($form)
}

function Show-GroupEditDialog([object]$Existing) {
    $f=New-Object System.Windows.Forms.Form;$f.Text="Edit Group - $($Existing.Name)";$f.Size=New-Object System.Drawing.Size(520,280);$f.StartPosition='CenterParent';$f.FormBorderStyle='FixedDialog';$f.MaximizeBox=$false
    $l1=New-Object System.Windows.Forms.Label;$l1.Text='Group Name';$l1.Location=New-Object System.Drawing.Point(20,30);$t1=New-Object System.Windows.Forms.TextBox;$t1.Location=New-Object System.Drawing.Point(140,27);$t1.Size=New-Object System.Drawing.Size(330,25);$t1.Text=$Existing.Name;$t1.ReadOnly=$true
    $l2=New-Object System.Windows.Forms.Label;$l2.Text='Description';$l2.Location=New-Object System.Drawing.Point(20,70);$t2=New-Object System.Windows.Forms.TextBox;$t2.Location=New-Object System.Drawing.Point(140,67);$t2.Size=New-Object System.Drawing.Size(330,50);$t2.Multiline=$true;$t2.Text=$Existing.Description
    $save=New-Object System.Windows.Forms.Button;$save.Text='Save Changes';$save.Location=New-Object System.Drawing.Point(140,140);$save.Size=New-Object System.Drawing.Size(120,34)
    $cancel=New-Object System.Windows.Forms.Button;$cancel.Text='Cancel';$cancel.Location=New-Object System.Drawing.Point(275,140);$cancel.Size=New-Object System.Drawing.Size(90,34)
    $f.Controls.AddRange(@($l1,$t1,$l2,$t2,$save,$cancel));$cancel.Add_Click({$f.Close()})
    $save.Add_Click({try{$g=New-LdapEntry $Existing.DN;$g.Properties['description'].Clear();if(-not [string]::IsNullOrWhiteSpace($t2.Text)){$g.Properties['description'].Value=$t2.Text.Trim()};$g.CommitChanges();$f.Close();Refresh-Groups;Show-Info 'Group updated successfully.'}catch{Show-Err "Group update failed:`r`n`r`n$($_.Exception.Message)"}})
    [void]$f.ShowDialog($form)
}

function Show-UserDetailsDialog([object]$User) {
    $f=New-Object System.Windows.Forms.Form;$f.Text="User Details - $($User.Username)";$f.Size=New-Object System.Drawing.Size(650,500);$f.StartPosition='CenterParent'
    $box=New-Object System.Windows.Forms.TextBox;$box.Multiline=$true;$box.ReadOnly=$true;$box.ScrollBars='Vertical';$box.Location=New-Object System.Drawing.Point(20,20);$box.Size=New-Object System.Drawing.Size(590,380)
    $box.Text="Username: $($User.Username)`r`nFirst Name: $($User.FirstName)`r`nLast Name: $($User.LastName)`r`nDisplay Name: $($User.DisplayName)`r`nEmail: $($User.Email)`r`nDescription: $($User.Description)`r`nEnabled: $($User.Enabled)`r`nDistinguished Name:`r`n$($User.DN)"
    $close=New-Object System.Windows.Forms.Button;$close.Text='Close';$close.Location=New-Object System.Drawing.Point(20,415);$close.Size=New-Object System.Drawing.Size(90,32);$close.Add_Click({$f.Close()})
    $f.Controls.AddRange(@($box,$close));[void]$f.ShowDialog($form)
}

function Show-AddUserToGroupDialog([object]$User) {
    $f=New-Object System.Windows.Forms.Form;$f.Text="Add $($User.Username) to Group";$f.Size=New-Object System.Drawing.Size(560,240);$f.StartPosition='CenterParent';$f.FormBorderStyle='FixedDialog';$f.MaximizeBox=$false
    $l=New-Object System.Windows.Forms.Label;$l.Text="Select group for $($User.Username):";$l.Location=New-Object System.Drawing.Point(20,25);$l.AutoSize=$true
    $c=New-Object System.Windows.Forms.ComboBox;$c.Location=New-Object System.Drawing.Point(20,55);$c.Size=New-Object System.Drawing.Size(490,28);$c.DropDownStyle='DropDownList'
    foreach($g in @(Get-Groups | Sort-Object Name)){[void]$c.Items.Add($g.Name)}
    if($c.Items.Count -gt 0){$c.SelectedIndex=0}
    $add=New-Object System.Windows.Forms.Button;$add.Text='Add to Group';$add.Location=New-Object System.Drawing.Point(20,105);$add.Size=New-Object System.Drawing.Size(110,34)
    $close=New-Object System.Windows.Forms.Button;$close.Text='Cancel';$close.Location=New-Object System.Drawing.Point(140,105);$close.Size=New-Object System.Drawing.Size(90,34);$close.Add_Click({$f.Close()})
    $f.Controls.AddRange(@($l,$c,$add,$close))
    $add.Add_Click({
        try {
            if ($c.SelectedItem -eq $null) { throw 'No group selected.' }
            $groupName = [string]$c.SelectedItem
            if ([string]::IsNullOrWhiteSpace($groupName)) { throw 'Invalid group name.' }
            Add-UserToGroup $User.DN $groupName
            $f.Close()
            Show-Info "User '$($User.Username)' was added to group '$groupName'."
        } catch { Show-Err "Add to group failed:`r`n`r`n$($_.Exception.Message)" }
    })
    [void]$f.ShowDialog($form)
}

function Show-GroupMembersDialog([object]$Group) {
    $f=New-Object System.Windows.Forms.Form;$f.Text="Manage Group Members - $($Group.Name)";$f.Size=New-Object System.Drawing.Size(900,600);$f.StartPosition='CenterParent';$f.MinimumSize=New-Object System.Drawing.Size(800,500)
    $lblCurrent=New-Object System.Windows.Forms.Label;$lblCurrent.Text="Current Members";$lblCurrent.Location=New-Object System.Drawing.Point(20,20);$lblCurrent.AutoSize=$true
    $lstMembers=New-Object System.Windows.Forms.ListBox;$lstMembers.Location=New-Object System.Drawing.Point(20,45);$lstMembers.Size=New-Object System.Drawing.Size(380,400);$lstMembers.SelectionMode='MultiExtended'
    $lblAvailable=New-Object System.Windows.Forms.Label;$lblAvailable.Text="Available Users";$lblAvailable.Location=New-Object System.Drawing.Point(480,20);$lblAvailable.AutoSize=$true
    $lstAvailable=New-Object System.Windows.Forms.ListBox;$lstAvailable.Location=New-Object System.Drawing.Point(480,45);$lstAvailable.Size=New-Object System.Drawing.Size(380,400);$lstAvailable.SelectionMode='MultiExtended'
    $btnAdd=New-Object System.Windows.Forms.Button;$btnAdd.Text="Add Selected  →";$btnAdd.Location=New-Object System.Drawing.Point(420,120);$btnAdd.Size=New-Object System.Drawing.Size(50,30)
    $btnRemove=New-Object System.Windows.Forms.Button;$btnRemove.Text="← Remove Selected";$btnRemove.Location=New-Object System.Drawing.Point(420,170);$btnRemove.Size=New-Object System.Drawing.Size(50,30)
    $btnRefresh=New-Object System.Windows.Forms.Button;$btnRefresh.Text="Refresh";$btnRefresh.Location=New-Object System.Drawing.Point(20,460);$btnRefresh.Size=New-Object System.Drawing.Size(100,30)
    $btnClose=New-Object System.Windows.Forms.Button;$btnClose.Text="Close";$btnClose.Location=New-Object System.Drawing.Point(130,460);$btnClose.Size=New-Object System.Drawing.Size(100,30)
    $f.Controls.AddRange(@($lblCurrent,$lstMembers,$lblAvailable,$lstAvailable,$btnAdd,$btnRemove,$btnRefresh,$btnClose))
    $btnClose.Add_Click({$f.Close()})

    function Load-Members {
        try {
            $lstMembers.Items.Clear()
            $lstAvailable.Items.Clear()
            $members = @(Get-GroupMembers $Group.DN | Sort-Object Username)
            $allUsers = @(Get-Users | Sort-Object Username)
            $memberUsernames = $members | ForEach-Object { $_.Username }
            foreach($m in $members) { [void]$lstMembers.Items.Add($m.Username) }
            foreach($u in $allUsers) {
                if ($memberUsernames -notcontains $u.Username) {
                    [void]$lstAvailable.Items.Add($u.Username)
                }
            }
        } catch {
            Show-Err "Unable to load members: $($_.Exception.Message)"
            Write-Log "LoadMembers error: $_"
        }
    }

    $btnRefresh.Add_Click({Load-Members})
    $btnAdd.Add_Click({
        try {
            if ($lstAvailable.SelectedItems.Count -eq 0) { throw 'Select one or more users to add.' }
            foreach($username in $lstAvailable.SelectedItems) {
                $u = Get-User $username
                if ($u) { Add-UserToGroup ([string]$u.Properties['distinguishedName'][0]) $Group.Name }
            }
            Load-Members
            Show-Info "Selected users added to group."
        } catch { Show-Err $_.Exception.Message }
    })
    $btnRemove.Add_Click({
        try {
            if ($lstMembers.SelectedItems.Count -eq 0) { throw 'Select one or more members to remove.' }
            foreach($username in $lstMembers.SelectedItems) {
                $u = Get-User $username
                if ($u) { Remove-UserFromGroup ([string]$u.Properties['distinguishedName'][0]) $Group.Name }
            }
            Load-Members
            Show-Info "Selected members removed from group."
        } catch { Show-Err $_.Exception.Message }
    })
    Load-Members
    [void]$f.ShowDialog($form)
}

# ---------- EVENT BINDING ----------
$btnRefresh.Add_Click({Refresh-Users})
$btnAdd.Add_Click({Show-UserDialog})
$btnEdit.Add_Click({$u=Selected-User;if($u){Show-UserDialog $u}})
$btnDetails.Add_Click({$u=Selected-User;if($u){Show-UserDetailsDialog $u}})
$btnAddGroup.Add_Click({$u=Selected-User;if($u){try{Show-AddUserToGroupDialog $u}catch{Show-Err "Unable to open group selector:`r`n`r`n$($_.Exception.Message)"}}})
$btnDelete.Add_Click({$u=Selected-User;if($u -and (Confirm "Delete user '$($u.Username)'? This cannot be undone.")){try{Delete-LdapObject $u.DN;Refresh-Users;Show-Info 'User deleted.'}catch{Show-Err "Delete failed:`r`n`r`n$($_.Exception.Message)"}}})
$btnReset.Add_Click({
    $u=Selected-User
    if($u){
        $f=New-Object System.Windows.Forms.Form
        $f.Text="Reset Password - $($u.Username)"
        $f.Size=New-Object System.Drawing.Size(470,210)
        $f.StartPosition='CenterParent'
        $l=New-Object System.Windows.Forms.Label;$l.Text='New password';$l.Location=New-Object System.Drawing.Point(20,30)
        $t=New-Object System.Windows.Forms.TextBox;$t.Location=New-Object System.Drawing.Point(140,27);$t.Size=New-Object System.Drawing.Size(280,25);$t.UseSystemPasswordChar=$true
        $b=New-Object System.Windows.Forms.Button;$b.Text='Reset';$b.Location=New-Object System.Drawing.Point(140,75);$b.Size=New-Object System.Drawing.Size(90,32)
        $c=New-Object System.Windows.Forms.Button;$c.Text='Cancel';$c.Location=New-Object System.Drawing.Point(240,75);$c.Size=New-Object System.Drawing.Size(90,32)
        $f.Controls.AddRange(@($l,$t,$b,$c))
        $c.Add_Click({$f.Close()})
        $b.Add_Click({
            try {
                Set-UserPassword $u.DN $t.Text
                $f.Close()
                Show-Info 'Password reset successfully.'
            } catch { Show-Err $_.Exception.Message }
        })
        [void]$f.ShowDialog($form)
    }
})
$btnToggle.Add_Click({
    $u=Selected-User
    if($u){
        try {
            Set-UserEnabled $u.DN (-not [bool]$u.Enabled)
            Refresh-Users
        } catch { Show-Err $_.Exception.Message }
    }
})

$gbRefresh.Add_Click({Refresh-Groups})
$gbAdd.Add_Click({Show-GroupDialog})
$gbMembers.Add_Click({$g=Selected-Group;if($g){Show-GroupMembersDialog $g}})
$gbEdit.Add_Click({$g=Selected-Group;if($g){Show-GroupEditDialog $g}})
$gbDetails.Add_Click({$g=Selected-Group;if($g){Show-Info "Group: $($g.Name)`r`nSAM: $($g.Sam)`r`nDescription: $($g.Description)`r`nDN: $($g.DN)" 'Group Details'}})
$gbDelete.Add_Click({$g=Selected-Group;if($g -and (Confirm "Delete group '$($g.Name)'? This cannot be undone.")){try{Delete-LdapObject $g.DN;Refresh-Groups;Show-Info 'Group deleted.'}catch{Show-Err "Delete failed:`r`n`r`n$($_.Exception.Message)"}}})

$obRefresh.Add_Click({Refresh-OUs})
$obAdd.Add_Click({
    $f=New-Object System.Windows.Forms.Form
    $f.Text='Create Organizational Unit'
    $f.Size=New-Object System.Drawing.Size(520,280)
    $f.StartPosition='CenterParent'
    $f.FormBorderStyle='FixedDialog'
    $f.MaximizeBox=$false
    $l=New-Object System.Windows.Forms.Label;$l.Text='OU Name';$l.Location=New-Object System.Drawing.Point(20,30)
    $t=New-Object System.Windows.Forms.TextBox;$t.Location=New-Object System.Drawing.Point(140,27);$t.Size=New-Object System.Drawing.Size(330,25)
    $l2=New-Object System.Windows.Forms.Label;$l2.Text='Parent';$l2.Location=New-Object System.Drawing.Point(20,75)
    $c=New-Object System.Windows.Forms.ComboBox;$c.Location=New-Object System.Drawing.Point(140,72);$c.Size=New-Object System.Drawing.Size(330,25);$c.DropDownStyle='DropDownList'
    [void]$c.Items.Add($Domain.DN)
    foreach($x in @(Get-OUs | Sort-Object DN)){[void]$c.Items.Add($x.DN)}
    $c.SelectedIndex=0
    $b=New-Object System.Windows.Forms.Button;$b.Text='Create OU';$b.Location=New-Object System.Drawing.Point(140,120);$b.Size=New-Object System.Drawing.Size(100,32)
    $cc=New-Object System.Windows.Forms.Button;$cc.Text='Cancel';$cc.Location=New-Object System.Drawing.Point(250,120);$cc.Size=New-Object System.Drawing.Size(90,32)
    $f.Controls.AddRange(@($l,$t,$l2,$c,$b,$cc))
    $cc.Add_Click({$f.Close()})
    $b.Add_Click({
        try {
            New-LdapOU $t.Text.Trim() $c.SelectedItem
            $f.Close()
            Refresh-OUs
            Show-Info 'OU created successfully.'
        } catch { Show-Err "OU creation failed:`r`n`r`n$($_.Exception.Message)" }
    })
    [void]$f.ShowDialog($form)
})
$obDelete.Add_Click({
    if($ogrid.SelectedRows.Count -eq 0){Show-Info 'Select an OU first.'}
    else{
        $o=$ogrid.SelectedRows[0].Tag
        if($o -and (Confirm "Delete OU '$($o.Name)' and its contents? This can be destructive.")){
            try{Delete-LdapObject $o.DN;Refresh-OUs;Show-Info 'OU deleted.'}catch{Show-Err "Delete failed:`r`n`r`n$($_.Exception.Message)"}
        }
    }
})

# Bulk event handlers
$browse.Add_Click({
    $d=New-Object System.Windows.Forms.OpenFileDialog
    $d.Filter='CSV files (*.csv)|*.csv|All files (*.*)|*.*'
    if($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK){
        $csvBox.Text=$d.FileName
    }
})
$sample.Add_Click({
    $d=New-Object System.Windows.Forms.SaveFileDialog
    $d.Filter='CSV files (*.csv)|*.csv'
    $d.FileName='Sample-AD-Users.csv'
    if($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK){
        @(
            [pscustomobject]@{Username='james.okoro';FirstName='James';LastName='Okoro';DisplayName='James Okoro';Email="james.okoro@$($Domain.DNS)";Description='Lab User';Password='P@ssword123!';OU=''}
            [pscustomobject]@{Username='mary.johnson';FirstName='Mary';LastName='Johnson';DisplayName='Mary Johnson';Email="mary.johnson@$($Domain.DNS)";Description='Lab User';Password='P@ssword456!';OU=''}
        ) | Export-Csv -NoTypeInformation -Encoding UTF8 $d.FileName
        $bulkLog.Text="Sample CSV created:`r`n$($d.FileName)"
    }
})
$import.Add_Click({
    try {
        if([string]::IsNullOrWhiteSpace($csvBox.Text) -or -not (Test-Path -LiteralPath $csvBox.Text)){
            throw 'Select a valid CSV file first.'
        }
        $rows=@(Import-Csv -LiteralPath $csvBox.Text)
        if($rows.Count -eq 0){ throw 'CSV is empty.' }
        $headers=@($rows[0].PSObject.Properties.Name)
        foreach($h in @('Username','Password')){
            if($headers -notcontains $h){ throw "Missing required CSV column: $h" }
        }
        $created=0;$skipped=0;$failed=0
        $log=New-Object System.Collections.Generic.List[string]
        foreach($r in $rows){
            try {
                $un=[string]$r.Username
                if([string]::IsNullOrWhiteSpace($un)){ throw 'Username is empty.' }
                if(Get-User $un){
                    $skipped++; $log.Add("SKIPPED: $un - user already exists")
                    continue
                }
                $path=$Domain.UsersContainer
                if(-not [string]::IsNullOrWhiteSpace([string]$r.OU)){
                    if([string]$r.OU -match '(?i)^(CN|OU|DC)='){
                        $path=[string]$r.OU
                    } else {
                        $path="OU=$([string]$r.OU),$($Domain.DN)"
                    }
                }
                [void](New-LdapUser @{
                    Username=$un
                    FirstName=[string]$r.FirstName
                    LastName=[string]$r.LastName
                    DisplayName=[string]$r.DisplayName
                    Email=[string]$r.Email
                    Description=[string]$r.Description
                    Password=[string]$r.Password
                    Enabled=$true
                    Path=$path
                })
                $created++; $log.Add("CREATED: $un")
            } catch {
                $failed++; $log.Add("FAILED: $($r.Username) - $($_.Exception.Message)")
            }
        }
        $bulkLog.Text = "IMPORT COMPLETE`r`n================`r`nCreated: $created`r`nSkipped: $skipped`r`nFailed: $failed`r`n`r`n" + ($log -join "`r`n")
        Refresh-Users
    } catch { Show-Err "Bulk import failed:`r`n`r`n$($_.Exception.Message)" }
})

# Tools
$diag.Add_Click({
    try {
        $r=Get-DomainInfo
        $toolOut.Text = "LDAP DIAGNOSTICS`r`n=================`r`nStatus: OK`r`nDNS Domain: $($r.DNS)`r`nDomain DN: $($r.DN)`r`nUsers Container: $($r.UsersContainer)`r`nComputers Container: $($r.ComputersContainer)`r`n`r`nRootDSE and naming context are accessible.`r`nADWS is not required."
    } catch {
        $toolOut.Text = "DIAGNOSTICS FAILED`r`n`r`n$($_.Exception.Message)"
    }
})
$openADUC.Add_Click({
    try { Start-Process dsa.msc } catch { Show-Err 'Active Directory Users and Computers (dsa.msc) is not installed on this computer.' }
})
$copyDomain.Add_Click({
    try {
        [System.Windows.Forms.Clipboard]::SetText("DNS=$($Domain.DNS)`r`nDN=$($Domain.DN)")
        Show-Info 'Domain information copied to clipboard.'
    } catch { Show-Err $_.Exception.Message }
})
$clearBtn.Add_Click({ $toolOut.Clear() })

# Selection enable/disable
$btnEdit.Enabled=$false;$btnDelete.Enabled=$false;$btnReset.Enabled=$false;$btnToggle.Enabled=$false;$btnAddGroup.Enabled=$false;$btnDetails.Enabled=$false
$gbMembers.Enabled=$false;$gbDelete.Enabled=$false;$gbEdit.Enabled=$false;$gbDetails.Enabled=$false

$grid.Add_SelectionChanged({
    $has = ($grid.SelectedRows.Count -gt 0)
    $btnEdit.Enabled = $has
    $btnDelete.Enabled = $has
    $btnReset.Enabled = $has
    $btnToggle.Enabled = $has
    $btnAddGroup.Enabled = $has
    $btnDetails.Enabled = $has
})
$ggrid.Add_SelectionChanged({
    $has = ($ggrid.SelectedRows.Count -gt 0)
    $gbMembers.Enabled = $has
    $gbDelete.Enabled = $has
    $gbEdit.Enabled = $has
    $gbDetails.Enabled = $has
})
$grid.Add_CellDoubleClick({
    param($sender,$e)
    if($e.RowIndex -ge 0){
        $u=$grid.Rows[$e.RowIndex].Tag
        if($u){ Show-UserDialog $u }
    }
})
$ggrid.Add_CellDoubleClick({
    param($sender,$e)
    if($e.RowIndex -ge 0){
        $g=$ggrid.Rows[$e.RowIndex].Tag
        if($g){ Show-GroupMembersDialog $g }
    }
})

# Navigation
$navHome.Add_Click({$tabs.SelectedTab=$tabHome})
$navUsers.Add_Click({$tabs.SelectedTab=$tabUsers; Refresh-Users})
$navGroups.Add_Click({$tabs.SelectedTab=$tabGroups; Refresh-Groups})
$navOU.Add_Click({$tabs.SelectedTab=$tabOU; Refresh-OUs})
$navBulk.Add_Click({$tabs.SelectedTab=$tabBulk})
$navTools.Add_Click({$tabs.SelectedTab=$tabTools})

# Home buttons
$homeAddUser.Add_Click({Show-UserDialog})
$homeManageUsers.Add_Click({$tabs.SelectedTab=$tabUsers; Refresh-Users})
$homeCreateGroup.Add_Click({Show-GroupDialog})
$homeManageGroups.Add_Click({$tabs.SelectedTab=$tabGroups; Refresh-Groups})
$homeOU.Add_Click({$tabs.SelectedTab=$tabOU; Refresh-OUs})
$homeBulk.Add_Click({$tabs.SelectedTab=$tabBulk})
$homeMembers.Add_Click({
    $tabs.SelectedTab=$tabGroups
    Refresh-Groups
    if($ggrid.Rows.Count -gt 0){
        $ggrid.Rows[0].Selected=$true
        Show-GroupMembersDialog $ggrid.Rows[0].Tag
    } else {
        Show-Info 'No groups were found. Create a group first.'
    }
})
$homeTools.Add_Click({$tabs.SelectedTab=$tabTools})

[void]$form.Add_Shown({$tabs.SelectedTab=$tabHome})
[void]$form.ShowDialog()